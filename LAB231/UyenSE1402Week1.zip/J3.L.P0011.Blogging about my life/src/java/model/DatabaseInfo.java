package model;

public interface DatabaseInfo {

    public static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static String dbURL = "jdbc:sqlserver://localhost:1433;databaseName=J3.L.P0011;";
    public static String userDB = "uyenlp";
    public static String passDB = "abcd";
}
